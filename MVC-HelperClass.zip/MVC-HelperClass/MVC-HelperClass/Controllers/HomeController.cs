﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_HelperClass.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Sample1()
        {
            List<string> l1 = new List<string>{ "Bsc", "Msc", "phd" ,"Mca"};
            List<string> l2 = new List<string> { "C", "C++", "java","Dotnet" };
            ViewData["cbl"] = new SelectList(l1);
            ViewData["lstBox"] = new SelectList(l2);
            return View();



        }
        public ActionResult Sample2()
        {
            List<string> l1 = new List<string> { "Bsc", "Msc", "phd", "Mca" };
            List<string> l2 = new List<string> { "C", "C++", "java", "Dotnet" };
            ViewData["cbl"] = new SelectList(l1);
            ViewData["lstBox"] = new SelectList(l2);
            return View();



        }
    }
}