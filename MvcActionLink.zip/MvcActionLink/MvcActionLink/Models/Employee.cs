﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcActionLink.Models
{
    public class Employee
    {
        public int pempid { get; set; }
        public string pempname { get; set; }
        public string  pdesignation { get; set; }
        public DateTime pdoj { get; set; }
        public double psalary { get; set; }
        public int pdeptno { get; set; }


    }
}