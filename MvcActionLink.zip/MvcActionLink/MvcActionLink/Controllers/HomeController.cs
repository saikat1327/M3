﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcActionLink.Models;

namespace MvcActionLink.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult sample1()
        {
            return View();
        }
        public ActionResult sample2()
        {
            return View();
        }
        public ActionResult sample3()
        {
            Employee obj = new Employee();
            obj.pempid = 101;
            obj.pempname = "kamal";
            obj.pdesignation = "projectmanager";
            obj.pdoj = DateTime.Now;
            obj.psalary = 65498.80;
            obj.pdeptno = 1;



            return View();
        }
    }
}